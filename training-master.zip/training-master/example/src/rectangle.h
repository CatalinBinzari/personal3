#ifndef TRAINING_RECTANGLE_H
#define TRAINING_RECTANGLE_H


#define TRUE  1
#define FALSE 0

int rectangle_area(int length, int width);

#endif //TRAINING_RECTANGLE_H 
