# Documentation

## C programming tutorials

https://www.programiz.com/c-programming
https://www.geeksforgeeks.org/c-programming-language/
http://www.trytoprogram.com/c-programming
https://beginnersbook.com/2014/01/c-tutorial-for-beginners-with-examples/

## Unit testing and cmocka tutorials

https://www.toptal.com/qa/how-to-write-testable-code-and-why-it-matters
https://lwn.net/Articles/558106/
https://blog.microjoe.org/2017/unit-tests-c-cmocka-coverage-cmake.html
https://www.samba.org/~asn/sambaxp_2018_andreas_schneider_cmocka.pdf

## Docker

TODO

## Build with make

TODO
